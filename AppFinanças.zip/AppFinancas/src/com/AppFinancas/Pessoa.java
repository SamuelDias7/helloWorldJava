package com.AppFinancas;

public class Pessoa {
	// Atributos
	public double salario;
	public double result;
	public double result2;
	
	// Métodos
	public double calcularSalario(double salario) {
		this.salario = salario;
		
		result = salario * 70 / 100;
		
		return result;
	
	}
	public double disponivel(double salario,double result) {
		this.salario = salario;
		this.result = result;
		
		result2 = salario - result;
		
		return result2;
	}

}
